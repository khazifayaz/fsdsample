package libraryservice.services;

import libraryservice.models.dto.BookResponseDTO;

public interface LibraryService {
    public BookResponseDTO findBookByName(String bookName);

    public void issueBook(Integer bookId, Integer userId);

    public void releaseBook(Integer bookId, Integer userId);
}
