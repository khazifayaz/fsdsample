package libraryservice.repo;

import libraryservice.entity.BookEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 */
public interface BookRepository extends JpaRepository<BookEntity, Integer> {

    public BookEntity findByTitle(String title);
}
