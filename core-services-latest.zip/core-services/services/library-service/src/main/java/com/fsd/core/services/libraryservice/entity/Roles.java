package com.fsd.core.services.libraryservice.entity;

/**
 * Created by fayaz on 29-11-2017.
 */
public enum Roles {

    LIBRARIAN, PATRON;
}
